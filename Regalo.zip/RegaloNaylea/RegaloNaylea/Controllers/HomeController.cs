using Microsoft.AspNetCore.Mvc;
using RegaloNaylea.Models;

namespace RegaloNaylea.Controllers
{
    public class HomeController : Controller
    {
        private static Regalo Datos()
        {
            var inicio = new DateTime(2025, 11, 11);
            return new Regalo
            {
                Para = "Naylea",
                De = "Joseph",
                Mensaje = "Espero que te guste, mi amor ❤️ Lo hice con todo mi corazón, solo para ti.",
                FechaInicio = inicio,
                FechaTexto = "11 DE NOVIEMBRE DE 2025",
                Lugar = "Todo empezó en Lima",
                SpotifyId = "4uLU6hMCjMI75M1A2tKUQC",
                Fotos = new List<string>
                {
                    "/img/foto1.jpg","/img/foto2.jpg","/img/foto3.jpg",
                    "/img/foto4.jpg","/img/foto5.jpg","/img/foto6.jpg"
                },
                Carta = new List<string>
                {
                    "Hola, mi amor.",
                    "Si estás leyendo esto es porque quería regalarte algo un poco diferente. Algo que no se guarda en una caja, sino en el corazón.",
                    "Todavía me acuerdo del día en que empezamos esta historia. Quién iba a decir que aquel día se iba a convertir en uno de los más importantes de mi vida.",
                    "Hemos vivido momentos muy bonitos, pero también otros que nos han hecho más fuertes. Y si algo he aprendido de nosotros es que, pase lo que pase, siempre merece la pena seguir caminando de tu mano.",
                    "Gracias por estar cuando más te he necesitado, por creer en mí incluso cuando yo dudaba y por hacer que cualquier lugar sea mi lugar favorito si tú estás allí.",
                    "Te amo.",
                    "— Joseph"
                },
                Hitos = new List<Hito>
{
    new Hito
    {
        Fecha = "",
        Titulo = "Nuestra primera Navidad juntos",
        Texto = "Nuestra primera Navidad juntos fue mágica. No importaban los regalos ni la cena, lo mejor de esa noche fue tenerte a mi lado. Gracias por hacer que esa fecha tan especial sea todavía más bonita. Quiero que sean muchas más.",
        Foto = "/img/hito1.jpg"
    },
    new Hito
    {
        Fecha = "",
        Titulo = "Un día de videojuegos con tus sobrinos",
        Texto = "Ese día entre videojuegos, risas y competencias con tus sobrinos me hizo ver lo bonito que es compartir tu mundo. Verte reír y ser tan cariñosa con ellos me enamoró aún más. Fue un día simple, pero perfecto.",
        Foto = "/img/hito2.jpg"
    },
    new Hito
    {
        Fecha = "",
        Titulo = "La primera vez en una cafetería",
        Texto = "Nuestra primera vez en una cafetería fue el inicio de muchas conversaciones largas y momentos tranquilos a tu lado. Un café contigo siempre sabe mejor. Me encanta cada rato que compartimos, sea donde sea.",
        Foto = "/img/hito3.jpg"
    }
},
                Preguntas = new List<Pregunta>
{
    new Pregunta { Texto = "¿Dónde fue nuestra primera cita?", Opciones = new List<string>{ "En un parque", "En una cancha de fútbol", "En un cerro" }, Correcta = 0 },
    new Pregunta { Texto = "¿Qué es lo que más me gusta a mí?", Opciones = new List<string>{ "Jugar videojuegos", "Besarte la papoi", "Pasar tiempo contigo" }, Correcta = 0 },
    new Pregunta { Texto = "¿Cuál es mi postre favorito?", Opciones = new List<string>{ "Tres leches", "Cualquier cosa de maracumango", "Postres de menta" }, Correcta = 0 }
},
                SorpresaTitulo = "¡Te ganaste una invitación a la cafetería Café Profundo!",
                SorpresaTexto = "Un café, una charla y mucho tiempo juntos. Gracias por conocerme tan bien, mi amor ❤️"
            };
        }

        public IActionResult Index() => View(Datos());

        public IActionResult Regalo() => View(Datos());
    }
}