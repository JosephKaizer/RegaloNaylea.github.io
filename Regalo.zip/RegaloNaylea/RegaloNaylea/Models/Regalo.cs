﻿namespace RegaloNaylea.Models
{
    public class Regalo
    {
        public string Para { get; set; } = "";
        public string De { get; set; } = "";
        public string Mensaje { get; set; } = "";
        public DateTime FechaInicio { get; set; }
        public string FechaTexto { get; set; } = "";
        public string Lugar { get; set; } = "";
        public string SpotifyId { get; set; } = "";
        public List<string> Fotos { get; set; } = new();
        public List<string> Carta { get; set; } = new();
        public List<Hito> Hitos { get; set; } = new();
        public List<Pregunta> Preguntas { get; set; } = new();
        public string SorpresaTitulo { get; set; } = "";
        public string SorpresaTexto { get; set; } = "";
    }

    public class Hito
    {
        public string Fecha { get; set; } = "";
        public string Titulo { get; set; } = "";
        public string Texto { get; set; } = "";
        public string Foto { get; set; } = "";
    }

    public class Pregunta
    {
        public string Texto { get; set; } = "";
        public List<string> Opciones { get; set; } = new();
        public int Correcta { get; set; }
    }
}