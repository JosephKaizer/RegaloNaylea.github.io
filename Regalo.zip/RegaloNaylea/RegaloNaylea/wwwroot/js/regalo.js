﻿// Aparición al hacer scroll
const io = new IntersectionObserver(es => {
    es.forEach(e => { if (e.isIntersecting) { e.target.classList.add('visible'); io.unobserve(e.target); } });
}, { threshold: 0.15 });
document.querySelectorAll('.reveal').forEach(el => io.observe(el));

// Días juntos
const dias = document.getElementById('dias');
if (dias) {
    const inicio = new Date(dias.dataset.inicio + 'T00:00:00');
    const total = Math.max(0, Math.floor((Date.now() - inicio) / 86400000));
    let n = 0;
    const paso = Math.max(1, Math.ceil(total / 60));
    const t = setInterval(() => {
        n = Math.min(total, n + paso);
        dias.textContent = n;
        if (n >= total) clearInterval(t);
    }, 20);
}

// Galería
const galeria = document.getElementById('galeria');
const puntos = document.getElementById('puntos');
const figs = galeria.querySelectorAll('figure');
figs.forEach(() => puntos.appendChild(document.createElement('span')));

function marcarPunto() {
    const centro = galeria.scrollLeft + galeria.clientWidth / 2;
    let idx = 0, min = Infinity;
    figs.forEach((f, k) => {
        const d = Math.abs(f.offsetLeft + f.offsetWidth / 2 - centro);
        if (d < min) { min = d; idx = k; }
    });
    figs.forEach((f, k) => f.classList.toggle('activa', k === idx));
    puntos.querySelectorAll('span').forEach((s, k) => s.classList.toggle('on', k === idx));
}
galeria.addEventListener('scroll', marcarPunto);
window.addEventListener('resize', marcarPunto);
marcarPunto();

let abajo = false, inicioX = 0, inicioScroll = 0;
galeria.addEventListener('mousedown', e => {
    abajo = true;
    inicioX = e.pageX;
    inicioScroll = galeria.scrollLeft;
    galeria.classList.add('arrastrando');
});
window.addEventListener('mouseup', () => {
    if (!abajo) return;
    abajo = false;
    galeria.classList.remove('arrastrando');
});
window.addEventListener('mousemove', e => {
    if (!abajo) return;
    galeria.scrollLeft = inicioScroll - (e.pageX - inicioX);
});

// Canción
const audioC = document.getElementById('audioCancion');
const btnC = document.getElementById('btnCancion');
const disco = document.getElementById('disco');
btnC.addEventListener('click', () => {
    if (audioC.paused) { audioC.play(); btnC.textContent = '❚❚'; disco.classList.add('gira'); }
    else { audioC.pause(); btnC.textContent = '▶'; disco.classList.remove('gira'); }
});
audioC.addEventListener('ended', () => { btnC.textContent = '▶'; disco.classList.remove('gira'); });

// Mensaje de voz
const onda = document.getElementById('onda');
for (let i = 0; i < 48; i++) {
    const b = document.createElement('i');
    b.style.height = (10 + Math.abs(Math.sin(i * 1.7) * 26) + (i % 5) * 3) + 'px';
    onda.appendChild(b);
}
const audioV = document.getElementById('audioVoz');
const btnV = document.getElementById('btnVoz');
const prog = document.getElementById('vozProgreso');
const tiempo = document.getElementById('vozTiempo');
const fmt = s => Math.floor(s / 60) + ':' + String(Math.floor(s % 60)).padStart(2, '0');
btnV.addEventListener('click', () => {
    if (audioV.paused) { audioV.play(); btnV.textContent = '❚❚'; }
    else { audioV.pause(); btnV.textContent = '🎙'; }
});
audioV.addEventListener('timeupdate', () => {
    prog.style.width = (audioV.currentTime / (audioV.duration || 1) * 100) + '%';
    tiempo.textContent = fmt(audioV.currentTime);
    const barras = onda.children;
    const hechas = Math.floor(audioV.currentTime / (audioV.duration || 1) * barras.length);
    for (let i = 0; i < barras.length; i++) barras[i].classList.toggle('on', i < hechas);
});
audioV.addEventListener('ended', () => { btnV.textContent = '🎙'; });

// Sorpresa final (quiz)
const modal = document.getElementById('modal');
const preguntas = document.querySelectorAll('.pregunta');
const pasos = document.querySelectorAll('#pasos span');
const quiz = document.getElementById('quiz');
const ganaste = document.getElementById('ganaste');
const perdiste = document.getElementById('perdiste');
let actual = 0;
let fallos = 0;

function mostrar(i) {
    preguntas.forEach((p, k) => p.classList.toggle('activa', k === i));
    pasos.forEach((s, k) => s.classList.toggle('on', k <= i));
}

function reiniciar() {
    actual = 0;
    fallos = 0;
    quiz.style.display = 'block';
    if (ganaste) ganaste.classList.remove('visible');
    if (perdiste) perdiste.classList.remove('visible');
    mostrar(0);
}

document.getElementById('btnSorpresa').addEventListener('click', () => {
    modal.classList.add('activo');
    reiniciar();
});
document.getElementById('cerrar').addEventListener('click', () => modal.classList.remove('activo'));

const btnReintentar = document.getElementById('reintentar');
if (btnReintentar) btnReintentar.addEventListener('click', reiniciar);

preguntas.forEach(p => {
    p.querySelectorAll('.opcion').forEach(o => {
        o.addEventListener('click', () => {
            if (o.dataset.ok !== '1') fallos++;
            actual++;
            if (actual < preguntas.length) {
                mostrar(actual);
                return;
            }
            quiz.style.display = 'none';
            if (fallos === 0) {
                if (ganaste) ganaste.classList.add('visible');
                lluviaCorazones();
            } else {
                if (perdiste) perdiste.classList.add('visible');
            }
        });
    });
});

function lluviaCorazones() {
    const cont = document.getElementById('lluvia');
    for (let i = 0; i < 30; i++) {
        const h = document.createElement('span');
        h.textContent = ['❤️', '💖', '💕'][i % 3];
        h.style.left = Math.random() * 100 + 'vw';
        h.style.animationDuration = (3 + Math.random() * 3) + 's';
        h.style.animationDelay = (Math.random() * 1.5) + 's';
        h.style.fontSize = (16 + Math.random() * 20) + 'px';
        cont.appendChild(h);
        setTimeout(() => h.remove(), 8000);
    }
}