﻿const corazon = document.getElementById('corazon');
const tarjeta = document.getElementById('tarjeta');
const relleno = document.getElementById('relleno');
const pista = document.getElementById('pista');
const abierto = document.getElementById('abierto');
const TOTAL = 7;
let clics = 0;

corazon.addEventListener('click', () => {
    if (clics >= TOTAL) return;
    clics++;

    if (clics === 1) {
        tarjeta.classList.add('oculto');
        corazon.classList.add('grande');
        pista.classList.add('fija');
        pista.textContent = 'Cada toque abre un pedacito del recuerdo.';
    }

    const altura = (clics / TOTAL) * 90;
    relleno.setAttribute('y', 90 - altura);
    relleno.setAttribute('height', altura);

    if (clics >= TOTAL) {
        setTimeout(() => abierto.classList.add('visible'), 700);
        setTimeout(() => { window.location.href = corazon.dataset.url; }, 2800);
    }
});