using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace RegaloNaylea.Views.Home
{
    public class RegaloModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
